// webpack.config.js (ESM style)
import path from "path";
import HtmlWebpackPlugin from "html-webpack-plugin";
const __dirname = path.resolve();

export default {
  entry: "./frontend/src/main.js",  
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "bundle.js",
    clean: true
  },
  module: {
    rules: [
      { test: /\.css$/i, use: ["style-loader", "css-loader"] },
      { test: /\.hbs$/i, loader: "handlebars-loader" }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./frontend/index.html",
      inject: "body"
    })
  ],
  mode: "production"
};

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { MongoClient, ObjectId } from "mongodb";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const URI = process.env.MONGODB_URI;
const DB_NAME = process.env.DB_NAME || "inft2202";
const COLLECTION = process.env.COLLECTION || "projects";
const TOKEN = process.env.TOKEN || "demo-token";

app.use(cors());
app.use(express.json());

// simple token validator (simulated auth)
function requireAuth(req, res, next) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (token !== TOKEN) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// optional root for sanity check
app.get("/", (_req, res) => {
  res.type("text").send("API OK. Use /projects (with Authorization: Bearer demo-token)");
});

const client = new MongoClient(URI);
let col;

// convert Mongo _id to string so frontend gets usable ids
function toClient(doc) {
  if (!doc) return doc;
  return { ...doc, _id: doc._id?.toString?.() || doc._id };
}

async function start() {
  await client.connect();
  col = client.db(DB_NAME).collection(COLLECTION);

  // list all projects
  app.get("/projects", requireAuth, async (_req, res) => {
    const docs = await col.find({}).sort({ _id: -1 }).toArray();
    res.json(docs.map(toClient));
  });

  // get one by id (for Edit screen)
  app.get("/projects/:id", requireAuth, async (req, res) => {
    const { id } = req.params;
    let doc;
    try {
      doc = await col.findOne({ _id: new ObjectId(id) });
    } catch (_e) {
      return res.status(400).json({ error: "Invalid id" });
    }
    if (!doc) return res.status(404).json({ error: "Not found" });
    res.json(toClient(doc));
  });

  // lazy-loaded unique skills list (optional)
  app.get("/skills", requireAuth, async (_req, res) => {
    const docs = await col.find({}, { projection: { skills: 1 } }).toArray();
    const skills = Array.from(new Set(docs.flatMap(d => d.skills || []))).sort();
    res.json(skills);
  });

  // create
  app.post("/projects", requireAuth, async (req, res) => {
    const { title, description, skills } = req.body;
    if (!title || !/^[a-z0-9 ]+$/i.test(title) || title.length > 50) {
      return res.status(400).json({ error: "Invalid title" });
    }
    if (!description || description.length > 200) {
      return res.status(400).json({ error: "Invalid description" });
    }
    const skillList = Array.isArray(skills) ? skills.filter(Boolean) : [];
    if (!skillList.length) {
      return res.status(400).json({ error: "At least one skill required" });
    }

    const result = await col.insertOne({ title, description, skills: skillList });
    const doc = await col.findOne({ _id: result.insertedId });
    res.status(201).json(toClient(doc));
  });

  // update
  app.put("/projects/:id", requireAuth, async (req, res) => {
    const { id } = req.params;
    const update = {};
    if (typeof req.body.title === "string") update.title = req.body.title;
    if (typeof req.body.description === "string") update.description = req.body.description;
    if (Array.isArray(req.body.skills)) update.skills = req.body.skills.filter(Boolean);

    let result;
    try {
      result = await col.findOneAndUpdate(
        { _id: new ObjectId(id) },
        { $set: update },
        { returnDocument: "after" }
      );
    } catch (_e) {
      return res.status(400).json({ error: "Invalid id" });
    }

    if (!result.value) return res.status(404).json({ error: "Not found" });
    res.json(toClient(result.value));
  });

  // delete
  app.delete("/projects/:id", requireAuth, async (req, res) => {
    const { id } = req.params;
    let r;
    try {
      r = await col.deleteOne({ _id: new ObjectId(id) });
    } catch (_e) {
      return res.status(400).json({ error: "Invalid id" });
    }
    if (!r.deletedCount) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  });

  app.listen(PORT, () => console.log(`API listening on http://localhost:${PORT}`));
}

start().catch(err => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
